# Modern Sherbet: A Modern WordPress Theme

## About Modern Sherbet

Modern Sherbet is a modern twist on the taste design of sherbet. It’s bright and colourful! There’s animated button on hover, there’s drop shadows (also known a box shadows) all around the theme.

The theme features shorcodes for toggles and further tabs. The theme is equipped with CSS for contact forms and Woocommerces. The theme features different styles for multiple post types which can be controlled in the WordPress Dashboard.

The CSS is commented at parts where you can change values in order to create your own spin on the design.

For support visit the [Donald Louch Productions Support Portal](https://dlproductions.freshdesk.com/) via. Freshdesk.

## Documentation

Theme documentation available [here](http://sherbet.theme.donaldlouch.ca/documentation/).

## License

This theme is licensed under  GNU General Public License v2 or later. You can feel free to modify it as loon gas you keep the original copyright information.
