			<?php get_header(); ?>
			
			<section class="error404Content">
				<h2>Oops! How embarrassing, that page can't be found...</h2>
				<p>It looks like nothing was found at this location. Maybe try a search?</p>
				<?php get_search_form(); ?>
			</section> <!-- Ends of Error 404 Page -->
				
			<?php get_footer();